﻿namespace сheckTheWebsite
{
    partial class formSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formSetting));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.categoryKeyWordsDataSet = new сheckTheWebsite.categoryKeyWordsDataSet();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.buttonView = new MetroFramework.Controls.MetroButton();
            this.textBoxGreatCount = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.textBoxGreatFreq = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.textBoxMinCount = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.textBoxMinFreq = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.buttonSaveSetting = new MetroFramework.Controls.MetroButton();
            this.textBoxDir = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.toggleKeyAKey = new MetroFramework.Controls.MetroToggle();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.категорияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ключевоеСловофразаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keyWordBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.keyWordsDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.keyWordsDataSet = new сheckTheWebsite.keyWordsDataSet();
            this.buttonSaveDB = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.buttonSaveSettingFull = new MetroFramework.Controls.MetroButton();
            this.textBoxCountProof = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.textBoxDephtFull = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.aKeyWordBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aKeyWordTableAdapter = new сheckTheWebsite.keyWordsDataSetTableAdapters.aKeyWordTableAdapter();
            this.keyWordTableAdapter = new сheckTheWebsite.keyWordsDataSetTableAdapters.keyWordTableAdapter();
            this.aKeyWordTableAdapter1 = new сheckTheWebsite.keyWordsDataSetTableAdapters.aKeyWordTableAdapter();
            this.categoryTableAdapter = new сheckTheWebsite.categoryKeyWordsDataSetTableAdapters.CategoryTableAdapter();
            this.категорияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryKeyWordsDataSet)).BeginInit();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.keyWordBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.keyWordsDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.keyWordsDataSet)).BeginInit();
            this.metroTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aKeyWordBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.HotTrack = true;
            this.metroTabControl1.Location = new System.Drawing.Point(7, 24);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(677, 571);
            this.metroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.White;
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTabControl1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabControl1.UseStyleColors = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.BackColor = System.Drawing.Color.White;
            this.metroTabPage1.Controls.Add(this.metroLabel9);
            this.metroTabPage1.Controls.Add(this.dataGridView1);
            this.metroTabPage1.Controls.Add(this.metroLabel8);
            this.metroTabPage1.Controls.Add(this.buttonView);
            this.metroTabPage1.Controls.Add(this.textBoxGreatCount);
            this.metroTabPage1.Controls.Add(this.metroLabel6);
            this.metroTabPage1.Controls.Add(this.textBoxGreatFreq);
            this.metroTabPage1.Controls.Add(this.metroLabel7);
            this.metroTabPage1.Controls.Add(this.textBoxMinCount);
            this.metroTabPage1.Controls.Add(this.metroLabel5);
            this.metroTabPage1.Controls.Add(this.textBoxMinFreq);
            this.metroTabPage1.Controls.Add(this.metroLabel4);
            this.metroTabPage1.Controls.Add(this.buttonSaveSetting);
            this.metroTabPage1.Controls.Add(this.textBoxDir);
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.ForeColor = System.Drawing.Color.White;
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(669, 529);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Настройки";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(300, 96);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(360, 95);
            this.metroLabel9.TabIndex = 16;
            this.metroLabel9.Text = resources.GetString("metroLabel9.Text");
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.категорияDataGridViewTextBoxColumn1});
            this.dataGridView1.DataSource = this.categoryBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView1.Location = new System.Drawing.Point(300, 196);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(356, 273);
            this.dataGridView1.TabIndex = 15;
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.categoryKeyWordsDataSet;
            // 
            // categoryKeyWordsDataSet
            // 
            this.categoryKeyWordsDataSet.DataSetName = "categoryKeyWordsDataSet";
            this.categoryKeyWordsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel8
            // 
            this.metroLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel8.BackColor = System.Drawing.Color.Maroon;
            this.metroLabel8.Location = new System.Drawing.Point(293, 97);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(1, 403);
            this.metroLabel8.TabIndex = 14;
            this.metroLabel8.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // buttonView
            // 
            this.buttonView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonView.Location = new System.Drawing.Point(535, 35);
            this.buttonView.Name = "buttonView";
            this.buttonView.Size = new System.Drawing.Size(94, 44);
            this.buttonView.TabIndex = 13;
            this.buttonView.Text = "Обзор";
            this.buttonView.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonView.Click += new System.EventHandler(this.buttonView_Click);
            // 
            // textBoxGreatCount
            // 
            this.textBoxGreatCount.Location = new System.Drawing.Point(12, 455);
            this.textBoxGreatCount.MaxLength = 12;
            this.textBoxGreatCount.Name = "textBoxGreatCount";
            this.textBoxGreatCount.Size = new System.Drawing.Size(114, 23);
            this.textBoxGreatCount.TabIndex = 12;
            this.textBoxGreatCount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.t_KeyPress);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(16, 395);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(277, 57);
            this.metroLabel6.TabIndex = 11;
            this.metroLabel6.Text = "Необходимый процент частоупотребимых \r\nключевых слов на странице, чтобы считать \r" +
    "\nконтент сайта опасным. ";
            // 
            // textBoxGreatFreq
            // 
            this.textBoxGreatFreq.Location = new System.Drawing.Point(13, 256);
            this.textBoxGreatFreq.MaxLength = 12;
            this.textBoxGreatFreq.Name = "textBoxGreatFreq";
            this.textBoxGreatFreq.Size = new System.Drawing.Size(114, 23);
            this.textBoxGreatFreq.TabIndex = 10;
            this.textBoxGreatFreq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.t_KeyPress);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(16, 196);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(237, 57);
            this.metroLabel7.TabIndex = 9;
            this.metroLabel7.Text = "Необходимая частота употребления \r\nключевого слова, чтобы считать его \r\nчастоупот" +
    "ребимым.";
            // 
            // textBoxMinCount
            // 
            this.textBoxMinCount.Location = new System.Drawing.Point(12, 356);
            this.textBoxMinCount.MaxLength = 12;
            this.textBoxMinCount.Name = "textBoxMinCount";
            this.textBoxMinCount.Size = new System.Drawing.Size(114, 23);
            this.textBoxMinCount.TabIndex = 8;
            this.textBoxMinCount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.t_KeyPress);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.ForeColor = System.Drawing.Color.White;
            this.metroLabel5.Location = new System.Drawing.Point(16, 296);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(277, 57);
            this.metroLabel5.TabIndex = 7;
            this.metroLabel5.Text = "Необходимый процент редкоупотребимых\r\nключевых слов на странице, чтобы считать \r\n" +
    "контент сайта опасным.";
            // 
            // textBoxMinFreq
            // 
            this.textBoxMinFreq.Location = new System.Drawing.Point(13, 156);
            this.textBoxMinFreq.MaxLength = 12;
            this.textBoxMinFreq.Name = "textBoxMinFreq";
            this.textBoxMinFreq.Size = new System.Drawing.Size(114, 23);
            this.textBoxMinFreq.TabIndex = 6;
            this.textBoxMinFreq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.t_KeyPress);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(13, 96);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(240, 57);
            this.metroLabel4.TabIndex = 5;
            this.metroLabel4.Text = "Минимальная частота употребления \r\nключевого слова, чтобы считать его \r\nприсутств" +
    "ующем на странице.";
            // 
            // buttonSaveSetting
            // 
            this.buttonSaveSetting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSaveSetting.Location = new System.Drawing.Point(535, 475);
            this.buttonSaveSetting.Name = "buttonSaveSetting";
            this.buttonSaveSetting.Size = new System.Drawing.Size(120, 40);
            this.buttonSaveSetting.TabIndex = 4;
            this.buttonSaveSetting.Text = "Сохранить";
            this.buttonSaveSetting.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonSaveSetting.Click += new System.EventHandler(this.buttonSaveSetting_Click);
            // 
            // textBoxDir
            // 
            this.textBoxDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDir.Location = new System.Drawing.Point(13, 35);
            this.textBoxDir.Multiline = true;
            this.textBoxDir.Name = "textBoxDir";
            this.textBoxDir.PromptText = "Расположение файла-отчета";
            this.textBoxDir.Size = new System.Drawing.Size(506, 44);
            this.textBoxDir.TabIndex = 3;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(13, 13);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(211, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Директория сохранения отчетов";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.toggleKeyAKey);
            this.metroTabPage2.Controls.Add(this.metroLabel3);
            this.metroTabPage2.Controls.Add(this.dataGridView);
            this.metroTabPage2.Controls.Add(this.buttonSaveDB);
            this.metroTabPage2.Controls.Add(this.metroLabel2);
            this.metroTabPage2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(669, 529);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "База ключевых слов";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            // 
            // toggleKeyAKey
            // 
            this.toggleKeyAKey.AutoSize = true;
            this.toggleKeyAKey.DisplayStatus = false;
            this.toggleKeyAKey.Location = new System.Drawing.Point(12, 494);
            this.toggleKeyAKey.Name = "toggleKeyAKey";
            this.toggleKeyAKey.Size = new System.Drawing.Size(50, 17);
            this.toggleKeyAKey.Style = MetroFramework.MetroColorStyle.Red;
            this.toggleKeyAKey.TabIndex = 10;
            this.toggleKeyAKey.Text = "Off";
            this.toggleKeyAKey.Theme = MetroFramework.MetroThemeStyle.Light;
            this.toggleKeyAKey.UseStyleColors = true;
            this.toggleKeyAKey.UseVisualStyleBackColor = true;
            this.toggleKeyAKey.CheckedChanged += new System.EventHandler(this.toggleKeyAKey_CheckedChanged);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(12, 472);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(465, 19);
            this.metroLabel3.TabIndex = 9;
            this.metroLabel3.Text = "Переключение между таблицами: ключевые слова / антиключевые слова.";
            // 
            // dataGridView
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Gainsboro;
            this.dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.категорияDataGridViewTextBoxColumn,
            this.ключевоеСловофразаDataGridViewTextBoxColumn});
            this.dataGridView.DataSource = this.keyWordBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView.EnableHeadersVisualStyles = false;
            this.dataGridView.GridColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView.Location = new System.Drawing.Point(0, 57);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersVisible = false;
            this.dataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.Size = new System.Drawing.Size(669, 407);
            this.dataGridView.TabIndex = 8;
            // 
            // категорияDataGridViewTextBoxColumn
            // 
            this.категорияDataGridViewTextBoxColumn.DataPropertyName = "Категория";
            this.категорияDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.категорияDataGridViewTextBoxColumn.HeaderText = "Категория";
            this.категорияDataGridViewTextBoxColumn.Items.AddRange(new object[] {
            "Наркотики",
            "Порнография",
            "Суицид",
            "Экстремизм"});
            this.категорияDataGridViewTextBoxColumn.Name = "категорияDataGridViewTextBoxColumn";
            this.категорияDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.категорияDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.категорияDataGridViewTextBoxColumn.ToolTipText = "Категория, к которой будет относится ключевое слово";
            // 
            // ключевоеСловофразаDataGridViewTextBoxColumn
            // 
            this.ключевоеСловофразаDataGridViewTextBoxColumn.DataPropertyName = "Ключевое слово/фраза";
            this.ключевоеСловофразаDataGridViewTextBoxColumn.FillWeight = 200F;
            this.ключевоеСловофразаDataGridViewTextBoxColumn.HeaderText = "Ключевое слово/фраза";
            this.ключевоеСловофразаDataGridViewTextBoxColumn.Name = "ключевоеСловофразаDataGridViewTextBoxColumn";
            // 
            // keyWordBindingSource
            // 
            this.keyWordBindingSource.DataMember = "keyWord";
            this.keyWordBindingSource.DataSource = this.keyWordsDataSetBindingSource;
            // 
            // keyWordsDataSetBindingSource
            // 
            this.keyWordsDataSetBindingSource.DataSource = this.keyWordsDataSet;
            this.keyWordsDataSetBindingSource.Position = 0;
            // 
            // keyWordsDataSet
            // 
            this.keyWordsDataSet.DataSetName = "keyWordsDataSet";
            this.keyWordsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonSaveDB
            // 
            this.buttonSaveDB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSaveDB.Location = new System.Drawing.Point(535, 475);
            this.buttonSaveDB.Name = "buttonSaveDB";
            this.buttonSaveDB.Size = new System.Drawing.Size(120, 40);
            this.buttonSaveDB.TabIndex = 6;
            this.buttonSaveDB.Text = "Сохранить";
            this.buttonSaveDB.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonSaveDB.Click += new System.EventHandler(this.buttonSaveDB_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(3, 13);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(335, 19);
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "База ключевых слов для поиска по страницам сайта.";
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.buttonSaveSettingFull);
            this.metroTabPage3.Controls.Add(this.textBoxCountProof);
            this.metroTabPage3.Controls.Add(this.metroLabel10);
            this.metroTabPage3.Controls.Add(this.textBoxDephtFull);
            this.metroTabPage3.Controls.Add(this.metroLabel11);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(669, 529);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Правила полной проверки";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            // 
            // buttonSaveSettingFull
            // 
            this.buttonSaveSettingFull.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSaveSettingFull.Location = new System.Drawing.Point(535, 475);
            this.buttonSaveSettingFull.Name = "buttonSaveSettingFull";
            this.buttonSaveSettingFull.Size = new System.Drawing.Size(120, 40);
            this.buttonSaveSettingFull.TabIndex = 15;
            this.buttonSaveSettingFull.Text = "Сохранить";
            this.buttonSaveSettingFull.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonSaveSettingFull.Click += new System.EventHandler(this.buttonSaveSettingFull_Click);
            // 
            // textBoxCountProof
            // 
            this.textBoxCountProof.Location = new System.Drawing.Point(12, 138);
            this.textBoxCountProof.MaxLength = 2;
            this.textBoxCountProof.Name = "textBoxCountProof";
            this.textBoxCountProof.Size = new System.Drawing.Size(114, 23);
            this.textBoxCountProof.TabIndex = 14;
            this.textBoxCountProof.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.t_KeyPressInt);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(15, 116);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(471, 19);
            this.metroLabel10.TabIndex = 13;
            this.metroLabel10.Text = "Количество ссылок на страницы, содержащие вредоносную информацию.";
            // 
            // textBoxDephtFull
            // 
            this.textBoxDephtFull.Location = new System.Drawing.Point(12, 61);
            this.textBoxDephtFull.MaxLength = 2;
            this.textBoxDephtFull.Name = "textBoxDephtFull";
            this.textBoxDephtFull.Size = new System.Drawing.Size(114, 23);
            this.textBoxDephtFull.TabIndex = 12;
            this.textBoxDephtFull.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.t_KeyPressInt);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(12, 16);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(433, 57);
            this.metroLabel11.TabIndex = 11;
            this.metroLabel11.Text = "Глубина полной проверки. \r\nЧем больше глубина, тем больше страниц сайта будет про" +
    "смотрено.\r\n";
            // 
            // aKeyWordBindingSource
            // 
            this.aKeyWordBindingSource.DataMember = "aKeyWord";
            this.aKeyWordBindingSource.DataSource = this.keyWordsDataSet;
            // 
            // aKeyWordTableAdapter
            // 
            this.aKeyWordTableAdapter.ClearBeforeFill = true;
            // 
            // keyWordTableAdapter
            // 
            this.keyWordTableAdapter.ClearBeforeFill = true;
            // 
            // aKeyWordTableAdapter1
            // 
            this.aKeyWordTableAdapter1.ClearBeforeFill = true;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // категорияDataGridViewTextBoxColumn1
            // 
            this.категорияDataGridViewTextBoxColumn1.DataPropertyName = "Категория";
            this.категорияDataGridViewTextBoxColumn1.HeaderText = "Категории";
            this.категорияDataGridViewTextBoxColumn1.Name = "категорияDataGridViewTextBoxColumn1";
            // 
            // formSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 600);
            this.Controls.Add(this.metroTabControl1);
            this.DisplayHeader = false;
            this.Name = "formSetting";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.ShadowType = MetroFramework.Forms.MetroForm.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Настройки и правила";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.formSetting_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryKeyWordsDataSet)).EndInit();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.keyWordBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.keyWordsDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.keyWordsDataSet)).EndInit();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aKeyWordBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox textBoxDir;
        private MetroFramework.Controls.MetroButton buttonSaveSetting;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroButton buttonSaveDB;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.BindingSource keyWordsDataSetBindingSource;
        private keyWordsDataSet keyWordsDataSet;
        private System.Windows.Forms.BindingSource aKeyWordBindingSource;
        private keyWordsDataSetTableAdapters.aKeyWordTableAdapter aKeyWordTableAdapter;
        private System.Windows.Forms.BindingSource keyWordBindingSource;
        private keyWordsDataSetTableAdapters.keyWordTableAdapter keyWordTableAdapter;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroToggle toggleKeyAKey;
        private keyWordsDataSetTableAdapters.aKeyWordTableAdapter aKeyWordTableAdapter1;
        private MetroFramework.Controls.MetroTextBox textBoxMinFreq;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox textBoxMinCount;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox textBoxGreatCount;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox textBoxGreatFreq;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroButton buttonView;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private categoryKeyWordsDataSet categoryKeyWordsDataSet;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private categoryKeyWordsDataSetTableAdapters.CategoryTableAdapter categoryTableAdapter;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroButton buttonSaveSettingFull;
        private MetroFramework.Controls.MetroTextBox textBoxCountProof;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroTextBox textBoxDephtFull;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private System.Windows.Forms.DataGridViewComboBoxColumn категорияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ключевоеСловофразаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn категорияDataGridViewTextBoxColumn1;
    }
}